<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
if (isLoggedIn()) { header('Location: app.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (login($_POST['username'] ?? '', $_POST['password'] ?? '')) {
        header('Location: app.php'); exit;
    }
    $error = 'Usuario o contraseña incorrectos.';
}
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>FarmaciaONG – Iniciar Sesión</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet"/>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{
  font-family:'Inter',sans-serif;
  background:#f5f5f5;
  min-height:100vh;
  display:flex; align-items:center; justify-content:center;
  position:relative;
}
body::before{
  content:''; position:fixed; inset:0;
  background-image:
    linear-gradient(rgba(0,0,0,.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,0,0,.04) 1px, transparent 1px);
  background-size:32px 32px; pointer-events:none;
}
.wrap{width:100%;max-width:420px;padding:20px;position:relative;z-index:1;animation:up .45s ease both;}
@keyframes up{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}
.card{background:#fff;border:1px solid #d4d4d4;border-radius:16px;padding:44px 40px 40px;box-shadow:0 8px 32px rgba(0,0,0,.12),0 0 1px rgba(0,0,0,.08);}
.logo{display:flex;align-items:center;gap:14px;margin-bottom:32px;}
.logo-icon{width:54px;height:54px;border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.12);}.logo-icon img{width:100%;height:100%;object-fit:contain;}
.logo h1{font-family:'Space Grotesk',sans-serif;font-size:20px;font-weight:700;color:#0a0a0a;letter-spacing:-.03em;line-height:1;}
.logo p{font-size:12px;color:#999;margin-top:3px;}
hr{border:none;border-top:1px solid #e0e0e0;margin-bottom:28px;}
h2{font-family:'Space Grotesk',sans-serif;font-size:22px;font-weight:700;color:#0a0a0a;letter-spacing:-.02em;margin-bottom:5px;}
.sub{font-size:13px;color:#999;margin-bottom:26px;}
.fg{margin-bottom:16px;}
.fg label{display:block;font-size:11px;font-weight:600;color:#555;letter-spacing:.06em;text-transform:uppercase;margin-bottom:7px;}
.fg input{width:100%;background:#f0f0f0;border:1.5px solid transparent;border-radius:10px;padding:12px 14px;color:#0a0a0a;font-size:14px;font-family:'Inter',sans-serif;outline:none;transition:.2s;}
.fg input::placeholder{color:#aaa;}
.fg input:focus{background:#fff;border-color:#0a0a0a;box-shadow:0 0 0 3px rgba(0,0,0,.08);}
.btn{width:100%;background:#0a0a0a;border:none;border-radius:10px;padding:13px;color:#fff;font-family:'Space Grotesk',sans-serif;font-size:14px;font-weight:600;cursor:pointer;margin-top:8px;transition:.2s;}
.btn:hover{background:#222;transform:translateY(-1px);box-shadow:0 4px 14px rgba(0,0,0,.2);}
.err{background:#fff0f0;border:1.5px solid #fecaca;border-radius:9px;padding:10px 14px;font-size:13px;color:#dc2626;margin-bottom:18px;}
.hint{margin-top:22px;padding-top:18px;border-top:1px solid #e8e8e8;text-align:center;font-size:12px;color:#aaa;}
.pills{display:flex;justify-content:center;gap:8px;margin-top:8px;}
.pill{background:#f5f5f5;border:1px solid #e0e0e0;border-radius:6px;padding:4px 10px;font-size:11px;color:#666;font-family:monospace;}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="logo">
      <div class="logo-icon"><img src="assets/img/logo_bienventuranzas.png" alt="Bienaventuranzas"/></div>
      <div>
        <h1>FarmaciaONG</h1>
        <p>Sistema de Gestión Farmacéutica</p>
      </div>
    </div>
    <hr/>
    <h2>Iniciar Sesión</h2>
    <p class="sub">Ingresa tus credenciales para continuar</p>
    <?php if ($error): ?>
    <div class="err">⚠ <?= h($error) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="fg"><label>Usuario</label><input type="text" name="username" placeholder="admin" autocomplete="username" required/></div>
      <div class="fg"><label>Contraseña</label><input type="password" name="password" placeholder="••••••••" autocomplete="current-password" required/></div>
      <button type="submit" class="btn">→ Ingresar al Sistema</button>
    </form>
    <div class="hint">
      Acceso por defecto
      <div class="pills">
        <span class="pill">admin</span>
        <span class="pill">admin123</span>
      </div>
    </div>
  </div>
</div>
</body>
</html>

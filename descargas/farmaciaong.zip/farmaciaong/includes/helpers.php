<?php
function catLabel(string $c): string {
    return [
        'medicines' => 'Medicamentos',
        'ampoules'  => 'Ampollas',
        'syrups'    => 'Jarabes',
        'drops'     => 'Gotas',
        'solutions' => 'Soluciones',
        'materials' => 'Materiales de Salud',
        'lotions'   => 'Lociones',
    ][$c] ?? $c;
}

function srcLabel(string $s): string {
    return [
        'own_purchase'   => 'Compra Propia',
        'mental_health'  => 'CSMC Sal. Mental',
        'other_hospital' => 'Otros Hospitales',
        'donation'       => 'Donación',
        'return'         => 'Devolución',
    ][$s] ?? $s;
}

function srcBadge(string $s): string {
    return [
        'own_purchase'   => 'badge-blue',
        'mental_health'  => 'badge-purple',
        'other_hospital' => 'badge-amber',
        'donation'       => 'badge-green',
        'return'         => 'badge-gray',
    ][$s] ?? 'badge-gray';
}

function fmtDate(?string $d): string {
    if (!$d) return '—';
    return date('d/m/Y', strtotime($d));
}

function genCode(string $prefix, PDO $db, string $table, string $col = 'codigo'): string {
    $stmt = $db->query("SELECT COUNT(*) FROM $table");
    $n    = (int)$stmt->fetchColumn() + 1;
    return strtoupper($prefix) . '-' . str_pad($n, 3, '0', STR_PAD_LEFT);
}

function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function h(mixed $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

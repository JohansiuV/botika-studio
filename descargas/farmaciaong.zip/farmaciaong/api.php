<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';

requireLogin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$pdo    = db();

switch ($action) {

    /* ── DASHBOARD ───────────────────────────────────── */
    case 'dashboard_stats':
        $today = date('Y-m-d');
        $stats = [];
        $stats['total_productos'] = $pdo->query("SELECT COUNT(*) FROM productos WHERE activo=1")->fetchColumn();
        $stats['total_pacientes'] = $pdo->query("SELECT COUNT(*) FROM pacientes WHERE activo=1")->fetchColumn();
        $stats['ingresos_hoy']    = $pdo->prepare("SELECT COUNT(*) FROM movimientos WHERE tipo='entry' AND fecha=?");
        $stats['ingresos_hoy']->execute([$today]);
        $stats['ingresos_hoy']    = $stats['ingresos_hoy']->fetchColumn();
        $stats['salidas_hoy']     = $pdo->prepare("SELECT COUNT(*) FROM movimientos WHERE tipo='exit' AND fecha=?");
        $stats['salidas_hoy']->execute([$today]);
        $stats['salidas_hoy']     = $stats['salidas_hoy']->fetchColumn();
        $stats['stock_bajo']      = $pdo->query("SELECT COUNT(*) FROM productos WHERE stock <= stock_min AND activo=1")->fetchColumn();

        $ultProds = $pdo->query("SELECT * FROM productos WHERE activo=1 ORDER BY id DESC LIMIT 6")->fetchAll();
        $ultMovs  = $pdo->query("SELECT m.*, p.nombre as prod_nombre FROM movimientos m LEFT JOIN productos p ON p.id=m.producto_id ORDER BY m.id DESC LIMIT 6")->fetchAll();

        jsonResponse(['stats' => $stats, 'productos' => $ultProds, 'movimientos' => $ultMovs]);

    /* ── PRODUCTOS ───────────────────────────────────── */
    case 'list_productos':
        $rows = $pdo->query("SELECT * FROM productos WHERE activo=1 ORDER BY nombre")->fetchAll();
        jsonResponse(['data' => $rows]);

    case 'save_producto':
        $id     = (int)($_POST['id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        if (!$nombre) jsonResponse(['error' => 'El nombre es obligatorio'], 422);

        $fields = [
            'nombre'        => $nombre,
            'categoria'     => $_POST['categoria']    ?? 'medicines',
            'origen'        => $_POST['origen']       ?? 'own_purchase',
            'presentacion'  => $_POST['presentacion'] ?? '',
            'concentracion' => $_POST['concentracion']?? '',
            'stock'         => (int)($_POST['stock']  ?? 0),
            'stock_min'     => (int)($_POST['stock_min'] ?? 10),
            'vencimiento'   => $_POST['vencimiento']  ?: null,
            'lote'          => $_POST['lote']         ?? '',
            'ubicacion'     => $_POST['ubicacion']    ?? '',
            'proveedor'     => $_POST['proveedor']    ?? '',
            'observaciones' => $_POST['observaciones']?? '',
        ];

        if ($id) {
            $set  = implode(', ', array_map(fn($k) => "$k = :$k", array_keys($fields)));
            $stmt = $pdo->prepare("UPDATE productos SET $set WHERE id = :id");
            $stmt->execute(array_merge($fields, ['id' => $id]));
            jsonResponse(['success' => true, 'msg' => 'Producto actualizado']);
        } else {
            $fields['codigo'] = trim($_POST['codigo'] ?? '') ?: genCode('FARM', $pdo, 'productos');
            $cols  = implode(', ', array_keys($fields));
            $vals  = ':' . implode(', :', array_keys($fields));
            $stmt  = $pdo->prepare("INSERT INTO productos ($cols) VALUES ($vals)");
            $stmt->execute($fields);
            jsonResponse(['success' => true, 'id' => $pdo->lastInsertId(), 'msg' => 'Producto registrado']);
        }

    case 'delete_producto':
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("UPDATE productos SET activo=0 WHERE id=?")->execute([$id]);
        jsonResponse(['success' => true]);

    /* ── MOVIMIENTOS ─────────────────────────────────── */
    case 'list_movimientos':
        $fuente = $_GET['fuente'] ?? '';
        $tipo   = $_GET['tipo']   ?? '';
        $sql    = "SELECT m.*, p.nombre as prod_nombre, p.categoria as prod_cat FROM movimientos m LEFT JOIN productos p ON p.id=m.producto_id WHERE 1=1";
        $params = [];
        if ($fuente) { $sql .= " AND m.fuente = ?"; $params[] = $fuente; }
        if ($tipo)   { $sql .= " AND m.tipo   = ?"; $params[] = $tipo;   }
        $sql .= " ORDER BY m.fecha DESC, m.id DESC";
        $stmt = $pdo->prepare($sql); $stmt->execute($params);
        jsonResponse(['data' => $stmt->fetchAll()]);

    case 'save_ingreso':
        $prodId = (int)($_POST['producto_id'] ?? 0);
        $qty    = (int)($_POST['cantidad']    ?? 0);
        if (!$prodId || $qty < 1) jsonResponse(['error' => 'Datos inválidos'], 422);

        $pdo->prepare("UPDATE productos SET stock = stock + ? WHERE id = ?")->execute([$qty, $prodId]);
        $stmt = $pdo->prepare("INSERT INTO movimientos (tipo, producto_id, cantidad, fuente, institucion, notas, fecha, usuario_id) VALUES ('entry', ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$prodId, $qty, $_POST['fuente'] ?? '', $_POST['institucion'] ?? '', $_POST['notas'] ?? '', $_POST['fecha'] ?? date('Y-m-d'), $_SESSION['user_id']]);
        jsonResponse(['success' => true, 'msg' => "Ingreso registrado: +$qty unidades"]);

    case 'save_salida':
        $prodId = (int)($_POST['producto_id'] ?? 0);
        $qty    = (int)($_POST['cantidad']    ?? 0);
        if (!$prodId || $qty < 1) jsonResponse(['error' => 'Datos inválidos'], 422);

        $prod = $pdo->prepare("SELECT stock FROM productos WHERE id=?");
        $prod->execute([$prodId]);
        $row = $prod->fetch();
        if (!$row || $row['stock'] < $qty) jsonResponse(['error' => 'Stock insuficiente. Disponible: ' . ($row['stock'] ?? 0)], 422);

        $pdo->prepare("UPDATE productos SET stock = stock - ? WHERE id = ?")->execute([$qty, $prodId]);
        $stmt = $pdo->prepare("INSERT INTO movimientos (tipo, producto_id, cantidad, destino, notas, fecha, usuario_id) VALUES ('exit', ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$prodId, $qty, $_POST['destino'] ?? '', $_POST['notas'] ?? '', $_POST['fecha'] ?? date('Y-m-d'), $_SESSION['user_id']]);
        jsonResponse(['success' => true, 'msg' => "Salida registrada: -$qty unidades"]);

    case 'delete_movimiento':
        $id  = (int)($_POST['id'] ?? 0);
        $mov = $pdo->prepare("SELECT * FROM movimientos WHERE id=?");
        $mov->execute([$id]);
        $m = $mov->fetch();
        if ($m) {
            $delta = $m['tipo'] === 'exit' ? $m['cantidad'] : -$m['cantidad'];
            $pdo->prepare("UPDATE productos SET stock = stock + ? WHERE id = ?")->execute([$delta, $m['producto_id']]);
            $pdo->prepare("DELETE FROM movimientos WHERE id = ?")->execute([$id]);
        }
        jsonResponse(['success' => true]);

    /* ── PACIENTES ───────────────────────────────────── */
    case 'list_pacientes':
        $rows = $pdo->query("SELECT * FROM pacientes WHERE activo=1 ORDER BY apellido, nombre")->fetchAll();
        jsonResponse(['data' => $rows]);

    case 'save_paciente':
        $id = (int)($_POST['id'] ?? 0);
        $fields = [
            'nombre'     => trim($_POST['nombre']    ?? ''),
            'apellido'   => trim($_POST['apellido']  ?? ''),
            'dni'        => $_POST['dni']       ?? '',
            'telefono'   => $_POST['telefono']  ?? '',
            'nacimiento' => $_POST['nacimiento']?: null,
            'genero'     => $_POST['genero']    ?? 'M',
            'direccion'  => $_POST['direccion'] ?? '',
            'historia'   => $_POST['historia']  ?? '',
        ];
        if (!$fields['nombre'] || !$fields['apellido']) jsonResponse(['error' => 'Nombre y apellido son obligatorios'], 422);

        if ($id) {
            $set  = implode(', ', array_map(fn($k) => "$k = :$k", array_keys($fields)));
            $stmt = $pdo->prepare("UPDATE pacientes SET $set WHERE id = :id");
            $stmt->execute(array_merge($fields, ['id' => $id]));
            jsonResponse(['success' => true, 'msg' => 'Paciente actualizado']);
        } else {
            $fields['codigo'] = genCode('PAC', $pdo, 'pacientes');
            $cols = implode(', ', array_keys($fields));
            $vals = ':' . implode(', :', array_keys($fields));
            $pdo->prepare("INSERT INTO pacientes ($cols) VALUES ($vals)")->execute($fields);
            jsonResponse(['success' => true, 'msg' => 'Paciente registrado']);
        }

    case 'delete_paciente':
        $pdo->prepare("UPDATE pacientes SET activo=0 WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        jsonResponse(['success' => true]);

    /* ── KARDEX ──────────────────────────────────────── */
    case 'list_kardex':
        $pid  = (int)($_GET['paciente_id'] ?? 0);
        $sql  = "SELECT k.*, p.nombre as prod_nombre, p.categoria as prod_cat, pac.nombre as pac_nombre, pac.apellido as pac_apellido, pac.codigo as pac_codigo, pac.dni as pac_dni, pac.historia as pac_historia FROM kardex k LEFT JOIN productos p ON p.id=k.producto_id LEFT JOIN pacientes pac ON pac.id=k.paciente_id WHERE k.paciente_id=? ORDER BY k.fecha DESC";
        $stmt = $pdo->prepare($sql); $stmt->execute([$pid]);
        $pac  = $pdo->prepare("SELECT * FROM pacientes WHERE id=?"); $pac->execute([$pid]);
        jsonResponse(['data' => $stmt->fetchAll(), 'paciente' => $pac->fetch()]);

    case 'save_kardex':
        $pacId  = (int)($_POST['paciente_id'] ?? 0);
        $prodId = (int)($_POST['producto_id'] ?? 0);
        $qty    = (int)($_POST['cantidad']    ?? 0);
        $tipo   = $_POST['tipo'] ?? 'exit';
        if (!$pacId || !$prodId || $qty < 1) jsonResponse(['error' => 'Datos inválidos'], 422);

        if ($tipo === 'exit') {
            $prod = $pdo->prepare("SELECT stock FROM productos WHERE id=?"); $prod->execute([$prodId]);
            $row  = $prod->fetch();
            if (!$row || $row['stock'] < $qty) jsonResponse(['error' => 'Stock insuficiente'], 422);
            $pdo->prepare("UPDATE productos SET stock = stock - ? WHERE id = ?")->execute([$qty, $prodId]);
        } else {
            $pdo->prepare("UPDATE productos SET stock = stock + ? WHERE id = ?")->execute([$qty, $prodId]);
        }
        $stmt = $pdo->prepare("INSERT INTO kardex (paciente_id, producto_id, tipo, cantidad, fecha, notas, usuario_id) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([$pacId, $prodId, $tipo, $qty, $_POST['fecha'] ?? date('Y-m-d'), $_POST['notas'] ?? '', $_SESSION['user_id']]);
        jsonResponse(['success' => true, 'msg' => 'Kardex registrado']);

    /* ── SELECT OPTIONS ──────────────────────────────── */
    case 'options_productos':
        $cat = $_GET['categoria'] ?? '';
        $sql = "SELECT id, nombre, stock FROM productos WHERE activo=1";
        $params = [];
        if ($cat) { $sql .= " AND categoria=?"; $params[] = $cat; }
        $sql .= " ORDER BY nombre";
        $stmt = $pdo->prepare($sql); $stmt->execute($params);
        jsonResponse(['data' => $stmt->fetchAll()]);

    case 'options_pacientes':
        $rows = $pdo->query("SELECT id, codigo, nombre, apellido, dni FROM pacientes WHERE activo=1 ORDER BY apellido")->fetchAll();
        jsonResponse(['data' => $rows]);

    default:
        jsonResponse(['error' => 'Acción no válida'], 400);
}

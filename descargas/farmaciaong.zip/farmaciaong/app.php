<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
requireLogin();
$user = currentUser();
?><!DOCTYPE html>
<html lang="es" data-theme="dark">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>FarmaciaONG – Sistema de Gestión</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@500;600;700;800&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="assets/css/app.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
</head>
<body>

<!-- SIDEBAR -->
<div id="sidebar">
  <div class="sidebar-header">
    <div class="sidebar-brand">
      <div class="b-icon"><img src="assets/img/logo_bienventuranzas.png" alt="Bienaventuranzas" style="width:38px;height:38px;object-fit:contain;border-radius:8px;background:#fff;padding:3px;"/></div>
      <div class="b-text"><span>Bienaventuranzas</span><small>v2.0 · ONG</small></div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">
      <div class="nav-section-title">Principal</div>
      <div class="nav-item active" data-page="dashboard" onclick="showPage('dashboard',this)"><span class="ni">📊</span>Dashboard</div>
      <div class="nav-item" data-page="productos" onclick="showPage('productos',this)"><span class="ni">📦</span>Productos</div>
    </div>
    <div class="nav-section">
      <div class="nav-section-title">Ingresos</div>
      <div class="nav-item" data-page="ing-compra" onclick="showPage('ing-compra',this)"><span class="ni">🛒</span>Compra Propia</div>
      <div class="nav-item" data-page="ing-csmc"   onclick="showPage('ing-csmc',this)"><span class="ni">🏥</span>CSMC - Sal. Mental</div>
      <div class="nav-item" data-page="ing-hosp"   onclick="showPage('ing-hosp',this)"><span class="ni">🏨</span>Otros Hospitales</div>
      <div class="nav-item" data-page="ing-don"    onclick="showPage('ing-don',this)"><span class="ni">🎁</span>Donaciones</div>
    </div>
    <div class="nav-section">
      <div class="nav-section-title">Salidas</div>
      <div class="nav-item" data-page="salidas"   onclick="showPage('salidas',this)"><span class="ni">📤</span>Salida en Bloque</div>
      <div class="nav-item" data-page="pacientes" onclick="showPage('pacientes',this)"><span class="ni">👥</span>Lista de Pacientes</div>
      <div class="nav-item" data-page="kardex"    onclick="showPage('kardex',this)"><span class="ni">📋</span>Kardex</div>
    </div>
    <div class="nav-section">
      <div class="nav-section-title">Categorías</div>
      <div class="nav-item" data-page="ampollas"   onclick="showPage('ampollas',this)"><span class="ni">💉</span>Ampollas</div>
      <div class="nav-item" data-page="jarabes"    onclick="showPage('jarabes',this)"><span class="ni">🍶</span>Jarabes</div>
      <div class="nav-item" data-page="gotas"      onclick="showPage('gotas',this)"><span class="ni">👁️</span>Gotas</div>
      <div class="nav-item" data-page="lociones"   onclick="showPage('lociones',this)"><span class="ni">🧴</span>Lociones</div>
      <div class="nav-item" data-page="soluciones" onclick="showPage('soluciones',this)"><span class="ni">💧</span>Soluciones</div>
      <div class="nav-item" data-page="materiales" onclick="showPage('materiales',this)"><span class="ni">🩺</span>Materiales</div>
    </div>
  </nav>
  <div class="sidebar-footer">
    <div class="user-info">
      <div class="avatar"><?= h(mb_strtoupper(mb_substr($user['nombre'] ?? 'A', 0, 1))) ?></div>
      <div style="flex:1;min-width:0;">
        <div class="uname"><?= h($user['nombre'] ?? 'Admin') ?></div>
        <div class="urole"><?= h($user['rol'] ?? 'admin') ?></div>
      </div>
    </div>
    <a href="logout.php" class="btn-logout">→ Cerrar Sesión</a>
  </div>
</div>

<!-- MAIN -->
<div id="main">
  <div class="topbar">
    <div>
      <div class="topbar-title" id="topbarTitle">Dashboard</div>
      <div class="topbar-sub" id="topbarSub">Resumen general del sistema</div>
    </div>
    <div class="topbar-actions">
      <button class="theme-toggle" onclick="toggleTheme()" id="themeBtn" title="Cambiar tema">🌙</button>
      <button class="btn btn-pdf" onclick="exportPDF()">📄 Exportar PDF</button>
      <a href="logout.php" style="display:inline-flex;align-items:center;gap:6px;padding:7px 13px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);border-radius:8px;color:#f87171;font-size:12px;font-weight:600;text-decoration:none;transition:.15s;" onmouseover="this.style.background='rgba(239,68,68,.2)'" onmouseout="this.style.background='rgba(239,68,68,.1)'">
        → Salir
      </a>
    </div>
  </div>

  <div class="content">

    <!-- DASHBOARD -->
    <div id="page-dashboard" class="page active">
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-label">Total Productos</div><div class="stat-value" id="d-totalProd">-</div><div class="stat-sub">En inventario</div><div class="stat-icon">📦</div></div>
        <div class="stat-card"><div class="stat-label">Pacientes</div><div class="stat-value" id="d-totalPac">-</div><div class="stat-sub">Registrados</div><div class="stat-icon">👥</div></div>
        <div class="stat-card"><div class="stat-label">Ingresos Hoy</div><div class="stat-value" id="d-ingHoy">-</div><div class="stat-sub">Movimientos</div><div class="stat-icon">📥</div></div>
        <div class="stat-card"><div class="stat-label">Stock Bajo</div><div class="stat-value" id="d-stockBajo">-</div><div class="stat-sub">Productos críticos</div><div class="stat-icon">⚠️</div></div>
        <div class="stat-card"><div class="stat-label">Salidas Hoy</div><div class="stat-value" id="d-salHoy">-</div><div class="stat-sub">Movimientos</div><div class="stat-icon">📤</div></div>
      </div>
      <div id="alertBar" class="alert-bar" style="display:none">
        <span>⚠</span><span id="alertMsg"></span>
      </div>
      <div class="grid2">
        <div class="table-card">
          <div class="table-header"><h3>📦 Últimos Productos</h3></div>
          <table><thead><tr><th>Producto</th><th>Categoría</th><th>Stock</th><th>Origen</th></tr></thead>
          <tbody id="dash-prod-table"><tr><td colspan="4" class="empty-state">Cargando...</td></tr></tbody></table>
        </div>
        <div class="table-card">
          <div class="table-header"><h3>📋 Últimos Movimientos</h3></div>
          <table><thead><tr><th>Tipo</th><th>Producto</th><th>Cant.</th><th>Fecha</th></tr></thead>
          <tbody id="dash-mov-table"><tr><td colspan="4" class="empty-state">Cargando...</td></tr></tbody></table>
        </div>
      </div>
    </div>

    <!-- PRODUCTOS -->
    <div id="page-productos" class="page">
      <div class="page-header">
        <div><h2>📦 Productos</h2><p>Inventario general de medicamentos e insumos</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('productos')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openNuevoProducto()">+ Nuevo Producto</button>
        </div>
      </div>
      <div class="table-card">
        <div class="table-header">
          <h3>Todos los Productos</h3>
          <div class="search-box">🔍 <input type="text" placeholder="Buscar..." oninput="filterTable('tblProductos',this.value)"/></div>
        </div>
        <table><thead><tr><th>Código</th><th>Nombre</th><th>Categoría</th><th>Stock</th><th>Vencimiento</th><th>Origen</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody id="tblProductos"></tbody></table>
      </div>
    </div>

    <!-- INGRESOS -->
    <div id="page-ing-compra" class="page">
      <div class="page-header">
        <div><h2>🛒 Ingreso – Compra Propia</h2><p>Medicamentos adquiridos por la ONG</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('ing-compra')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openIngreso('own_purchase')">+ Registrar Ingreso</button>
        </div>
      </div>
      <div class="table-card">
        <div class="table-header"><h3>Ingresos por Compra Propia</h3>
          <div class="search-box">🔍 <input type="text" placeholder="Buscar..." oninput="filterTable('tbl-compra',this.value)"/></div>
        </div>
        <table><thead><tr><th>Fecha</th><th>Producto</th><th>Categoría</th><th>Cantidad</th><th>Proveedor</th><th>Notas</th><th>Acciones</th></tr></thead>
        <tbody id="tbl-compra"></tbody></table>
      </div>
    </div>

    <div id="page-ing-csmc" class="page">
      <div class="page-header">
        <div><h2>🏥 Ingreso – CSMC Salud Mental</h2><p>Centro de Salud Mental Comunitario</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('ing-csmc')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openIngreso('mental_health')">+ Registrar Ingreso</button>
        </div>
      </div>
      <div class="table-card">
        <div class="table-header"><h3>Ingresos CSMC</h3>
          <div class="search-box">🔍 <input type="text" placeholder="Buscar..." oninput="filterTable('tbl-csmc',this.value)"/></div>
        </div>
        <table><thead><tr><th>Fecha</th><th>Producto</th><th>Categoría</th><th>Cantidad</th><th>Institución</th><th>Notas</th><th>Acciones</th></tr></thead>
        <tbody id="tbl-csmc"></tbody></table>
      </div>
    </div>

    <div id="page-ing-hosp" class="page">
      <div class="page-header">
        <div><h2>🏨 Ingreso – Otros Hospitales</h2><p>Consultas externas y otros hospitales</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('ing-hosp')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openIngreso('other_hospital')">+ Registrar Ingreso</button>
        </div>
      </div>
      <div class="table-card">
        <div class="table-header"><h3>Ingresos de Otros Hospitales</h3>
          <div class="search-box">🔍 <input type="text" placeholder="Buscar..." oninput="filterTable('tbl-hosp',this.value)"/></div>
        </div>
        <table><thead><tr><th>Fecha</th><th>Producto</th><th>Categoría</th><th>Cantidad</th><th>Hospital</th><th>Notas</th><th>Acciones</th></tr></thead>
        <tbody id="tbl-hosp"></tbody></table>
      </div>
    </div>

    <div id="page-ing-don" class="page">
      <div class="page-header">
        <div><h2>🎁 Ingreso – Donaciones</h2><p>Medicamentos recibidos por donación</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('ing-don')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openIngreso('donation')">+ Registrar Donación</button>
        </div>
      </div>
      <div class="table-card">
        <div class="table-header"><h3>Ingresos por Donación</h3>
          <div class="search-box">🔍 <input type="text" placeholder="Buscar..." oninput="filterTable('tbl-don',this.value)"/></div>
        </div>
        <table><thead><tr><th>Fecha</th><th>Producto</th><th>Categoría</th><th>Cantidad</th><th>Donante</th><th>Notas</th><th>Acciones</th></tr></thead>
        <tbody id="tbl-don"></tbody></table>
      </div>
    </div>

    <!-- SALIDAS -->
    <div id="page-salidas" class="page">
      <div class="page-header">
        <div><h2>📤 Salida en Bloque</h2><p>Registrar salidas masivas de medicamentos</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('salidas')">📄 PDF</button>
          <button class="btn btn-danger" onclick="openSalida()">+ Registrar Salida</button>
        </div>
      </div>
      <div class="table-card">
        <div class="table-header"><h3>Salidas Registradas</h3>
          <div class="search-box">🔍 <input type="text" placeholder="Buscar..." oninput="filterTable('tblSalidas',this.value)"/></div>
        </div>
        <table><thead><tr><th>Fecha</th><th>Producto</th><th>Cantidad</th><th>Destino</th><th>Notas</th><th>Acciones</th></tr></thead>
        <tbody id="tblSalidas"></tbody></table>
      </div>
    </div>

    <!-- PACIENTES -->
    <div id="page-pacientes" class="page">
      <div class="page-header">
        <div><h2>👥 Lista de Pacientes</h2><p>Gestión de pacientes registrados</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('pacientes')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openNuevoPaciente()">+ Nuevo Paciente</button>
        </div>
      </div>
      <div class="table-card">
        <div class="table-header"><h3>Pacientes</h3>
          <div class="search-box">🔍 <input type="text" placeholder="Buscar..." oninput="filterTable('tblPacientes',this.value)"/></div>
        </div>
        <table><thead><tr><th>Código</th><th>Nombre</th><th>DNI</th><th>Teléfono</th><th>Género</th><th>Acciones</th></tr></thead>
        <tbody id="tblPacientes"></tbody></table>
      </div>
    </div>

    <!-- KARDEX -->
    <div id="page-kardex" class="page">
      <div class="page-header">
        <div><h2>📋 Kardex de Paciente</h2><p>Historial de medicamentos por paciente</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('kardex')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openKardexEntry()">+ Registrar en Kardex</button>
        </div>
      </div>
      <div class="kardex-header">
        <div class="kh-item"><label>Paciente</label><p id="kh-nombre">-</p></div>
        <div class="kh-item"><label>Código</label><p id="kh-codigo">-</p></div>
        <div class="kh-item"><label>DNI</label><p id="kh-dni">-</p></div>
        <div class="kh-item"><label>Historia Clínica</label><p id="kh-historia">-</p></div>
      </div>
      <div class="table-card">
        <div class="table-header"><h3>Movimientos del Paciente</h3></div>
        <table><thead><tr><th>Fecha</th><th>Medicamento</th><th>Categoría</th><th>Tipo</th><th>Cantidad</th><th>Notas</th></tr></thead>
        <tbody id="tblKardex"><tr><td colspan="6" class="empty-state">Selecciona un paciente desde la lista de pacientes</td></tr></tbody></table>
      </div>
    </div>

    <!-- CATEGORÍAS -->
    <div id="page-ampollas" class="page">
      <div class="page-header"><div><h2>💉 Ampollas</h2><p>Ingresos y movimientos de ampollas</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('ampollas')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openIngreso('own_purchase','ampoules')">+ Registrar Ingreso</button>
        </div></div>
      <div id="cat-content-ampollas"></div>
    </div>
    <div id="page-jarabes" class="page">
      <div class="page-header"><div><h2>🍶 Jarabes</h2><p>Ingresos y movimientos de jarabes</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('jarabes')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openIngreso('own_purchase','syrups')">+ Registrar Ingreso</button>
        </div></div>
      <div id="cat-content-jarabes"></div>
    </div>
    <div id="page-gotas" class="page">
      <div class="page-header"><div><h2>👁️ Gotas Oftalmológicas y Óticas</h2><p>Medicamentos en forma de gotas</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('gotas')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openIngreso('own_purchase','drops')">+ Registrar Ingreso</button>
        </div></div>
      <div id="cat-content-gotas"></div>
    </div>
    <div id="page-lociones" class="page">
      <div class="page-header"><div><h2>🧴 Lociones Varias</h2><p>Lociones y cremas</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('lociones')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openIngreso('own_purchase','lotions')">+ Registrar Ingreso</button>
        </div></div>
      <div id="cat-content-lociones"></div>
    </div>
    <div id="page-soluciones" class="page">
      <div class="page-header"><div><h2>💧 Soluciones</h2><p>Cloruro de Sodio, Dextrosa, Agua Estéril, Suero Oral</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('soluciones')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openIngreso('own_purchase','solutions')">+ Registrar Ingreso</button>
        </div></div>
      <div id="cat-content-soluciones"></div>
    </div>
    <div id="page-materiales" class="page">
      <div class="page-header"><div><h2>🩺 Materiales de Salud</h2><p>Insumos y materiales médicos</p></div>
        <div class="page-actions">
          <button class="btn btn-pdf" onclick="exportPagePDF('materiales')">📄 PDF</button>
          <button class="btn btn-primary" onclick="openIngreso('own_purchase','materials')">+ Registrar Ingreso</button>
        </div></div>
      <div id="cat-content-materiales"></div>
    </div>

  </div><!-- /content -->
</div><!-- /main -->

<!-- MODALS (same as before, visually updated by CSS) -->
<div class="modal-overlay" id="modalProducto">
  <div class="modal modal-lg">
    <div class="modal-header">
      <h3 id="modalProductoTitle">Nuevo Producto</h3>
      <button class="modal-close" onclick="closeModal('modalProducto')">✕</button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="prod-id"/>
      <div class="form-grid">
        <div class="field"><label>Código</label><input id="p-codigo" placeholder="FARM-001"/></div>
        <div class="field"><label>Nombre *</label><input id="p-nombre" placeholder="Nombre del medicamento"/></div>
        <div class="field"><label>Categoría *</label>
          <select id="p-cat">
            <option value="medicines">Medicamentos</option><option value="ampoules">Ampollas</option>
            <option value="syrups">Jarabes</option><option value="drops">Gotas</option>
            <option value="solutions">Soluciones</option><option value="materials">Materiales de Salud</option>
            <option value="lotions">Lociones</option>
          </select>
        </div>
        <div class="field"><label>Origen *</label>
          <select id="p-origen">
            <option value="own_purchase">Compra Propia</option>
            <option value="mental_health">CSMC - Salud Mental</option>
            <option value="other_hospital">Otros Hospitales</option>
            <option value="donation">Donación</option>
          </select>
        </div>
        <div class="field"><label>Presentación</label><input id="p-pres" placeholder="Tableta, Ampolla, Frasco..."/></div>
        <div class="field"><label>Concentración</label><input id="p-conc" placeholder="500mg, 10ml..."/></div>
        <div class="field"><label>Stock Inicial</label><input id="p-stock" type="number" min="0" value="0"/></div>
        <div class="field"><label>Stock Mínimo</label><input id="p-stockmin" type="number" min="0" value="10"/></div>
        <div class="field"><label>Fecha de Vencimiento</label><input id="p-vence" type="date"/></div>
        <div class="field"><label>Lote</label><input id="p-lote" placeholder="LOT-2024-01"/></div>
        <div class="field"><label>Ubicación</label><input id="p-ubic" placeholder="Estante A-3"/></div>
        <div class="field"><label>Proveedor / Institución</label><input id="p-prov" placeholder="Nombre del proveedor"/></div>
        <div class="field form-full"><label>Observaciones</label><textarea id="p-obs" placeholder="Notas adicionales..."></textarea></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalProducto')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveProducto()">💾 Guardar Producto</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="modalIngreso">
  <div class="modal">
    <div class="modal-header">
      <h3 id="modalIngresoTitle">Registrar Ingreso</h3>
      <button class="modal-close" onclick="closeModal('modalIngreso')">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-grid">
        <div class="field"><label>Producto *</label><select id="ing-prod"><option value="">Seleccionar...</option></select></div>
        <div class="field"><label>Cantidad *</label><input id="ing-qty" type="number" min="1" value="1"/></div>
        <div class="field"><label>Fecha</label><input id="ing-fecha" type="date"/></div>
        <div class="field"><label>Institución / Proveedor</label><input id="ing-inst" placeholder="Nombre del proveedor..."/></div>
        <div class="field form-full"><label>Notas</label><textarea id="ing-notas" placeholder="Observaciones del ingreso..."></textarea></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalIngreso')">Cancelar</button>
      <button class="btn btn-success" onclick="saveIngreso()">✓ Registrar Ingreso</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="modalSalida">
  <div class="modal">
    <div class="modal-header">
      <h3>Registrar Salida</h3>
      <button class="modal-close" onclick="closeModal('modalSalida')">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-grid">
        <div class="field"><label>Producto *</label><select id="sal-prod"><option value="">Seleccionar...</option></select></div>
        <div class="field"><label>Cantidad *</label><input id="sal-qty" type="number" min="1" value="1"/></div>
        <div class="field"><label>Destino</label><input id="sal-dest" placeholder="Paciente, área, servicio..."/></div>
        <div class="field"><label>Fecha</label><input id="sal-fecha" type="date"/></div>
        <div class="field form-full"><label>Notas</label><textarea id="sal-notas" placeholder="Motivo de la salida..."></textarea></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalSalida')">Cancelar</button>
      <button class="btn btn-danger" onclick="saveSalida()">📤 Registrar Salida</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="modalPaciente">
  <div class="modal">
    <div class="modal-header">
      <h3 id="modalPacienteTitle">Nuevo Paciente</h3>
      <button class="modal-close" onclick="closeModal('modalPaciente')">✕</button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="pac-id"/>
      <div class="form-grid">
        <div class="field"><label>Nombres *</label><input id="pac-nombre" placeholder="Nombres del paciente"/></div>
        <div class="field"><label>Apellidos *</label><input id="pac-apellido" placeholder="Apellidos"/></div>
        <div class="field"><label>DNI</label><input id="pac-dni" placeholder="12345678"/></div>
        <div class="field"><label>Teléfono</label><input id="pac-tel" placeholder="999 999 999"/></div>
        <div class="field"><label>Fecha de Nacimiento</label><input id="pac-nac" type="date"/></div>
        <div class="field"><label>Género</label>
          <select id="pac-gen"><option value="M">Masculino</option><option value="F">Femenino</option><option value="other">Otro</option></select>
        </div>
        <div class="field form-full"><label>Dirección</label><input id="pac-dir" placeholder="Dirección del paciente"/></div>
        <div class="field form-full"><label>Historia Clínica / Notas</label><textarea id="pac-hist" placeholder="Notas médicas relevantes..."></textarea></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalPaciente')">Cancelar</button>
      <button class="btn btn-primary" onclick="savePaciente()">💾 Guardar Paciente</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="modalKardexEntry">
  <div class="modal">
    <div class="modal-header">
      <h3>Registrar en Kardex</h3>
      <button class="modal-close" onclick="closeModal('modalKardexEntry')">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-grid">
        <div class="field"><label>Paciente *</label><select id="ke-pac"><option value="">Seleccionar paciente...</option></select></div>
        <div class="field"><label>Producto *</label><select id="ke-prod"><option value="">Seleccionar producto...</option></select></div>
        <div class="field"><label>Tipo</label>
          <select id="ke-tipo"><option value="exit">Entrega (Salida)</option><option value="entry">Devolución (Entrada)</option></select>
        </div>
        <div class="field"><label>Cantidad *</label><input id="ke-qty" type="number" min="1" value="1"/></div>
        <div class="field"><label>Fecha</label><input id="ke-fecha" type="date"/></div>
        <div class="field form-full"><label>Notas</label><textarea id="ke-notas" placeholder="Indicaciones, observaciones..."></textarea></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalKardexEntry')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveKardexEntry()">💾 Guardar en Kardex</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="modalConfirm">
  <div class="modal modal-sm">
    <div class="modal-header">
      <h3>Confirmar Eliminación</h3>
      <button class="modal-close" onclick="closeModal('modalConfirm')">✕</button>
    </div>
    <div class="modal-body">
      <p style="color:var(--text2);font-size:13.5px;line-height:1.6">¿Estás seguro de que deseas eliminar este registro? Esta acción no se puede deshacer.</p>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalConfirm')">Cancelar</button>
      <button class="btn btn-danger" id="confirmDeleteBtn">🗑️ Eliminar</button>
    </div>
  </div>
</div>

<div id="toast"></div>
<script src="assets/js/app.js"></script>
</body>
</html>

/* FarmaciaONG – app.js v3 */

/* ── API HELPER ──────────────────────────────────────────── */
async function api(action, params = {}, method = 'GET') {
  const isGet = method === 'GET';
  let url = `api.php?action=${action}`;
  let opts = { method };
  if (isGet) {
    Object.entries(params).forEach(([k,v]) => url += `&${k}=${encodeURIComponent(v)}`);
  } else {
    const fd = new FormData();
    fd.append('action', action);
    Object.entries(params).forEach(([k,v]) => fd.append(k, v ?? ''));
    opts.body = fd;
  }
  const res  = await fetch(url, opts);
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data;
}

/* ── HELPERS ─────────────────────────────────────────────── */
const CAT_LABELS = {medicines:'Medicamentos',ampoules:'Ampollas',syrups:'Jarabes',drops:'Gotas',solutions:'Soluciones',materials:'Materiales de Salud',lotions:'Lociones'};
const SRC_LABELS = {own_purchase:'Compra Propia',mental_health:'CSMC Sal. Mental',other_hospital:'Otros Hospitales',donation:'Donación',return:'Devolución'};
const SRC_BADGE  = {own_purchase:'badge-blue',mental_health:'badge-purple',other_hospital:'badge-amber',donation:'badge-green',return:'badge-gray'};

function catLabel(c) { return CAT_LABELS[c] || c; }
function srcLabel(s) { return SRC_LABELS[s] || s; }
function srcBadge(s) { return SRC_BADGE[s]  || 'badge-gray'; }
function fmtDate(d)  { if (!d || d==='0000-00-00') return '—'; const [y,m,dy]=d.split('-'); return `${dy}/${m}/${y}`; }
function h(v)        { const e=document.createElement('div'); e.textContent=v??''; return e.innerHTML; }

function showToast(msg, type = 'info') {
  const icons = {success:'✅',error:'❌',info:'ℹ️'};
  const t = document.createElement('div');
  t.className = `toast-msg ${type}`;
  t.innerHTML = `<span>${icons[type]||'ℹ️'}</span><span>${h(msg)}</span>`;
  document.getElementById('toast').appendChild(t);
  setTimeout(() => t.remove(), 3500);
}
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
function filterTable(tableId, val) {
  document.querySelectorAll(`#${tableId} tr`).forEach(r => {
    r.style.display = r.innerText.toLowerCase().includes(val.toLowerCase()) ? '' : 'none';
  });
}
async function fillSelect(selId, action, params = {}, valueFn, labelFn) {
  const sel = document.getElementById(selId);
  sel.innerHTML = '<option value="">Seleccionar...</option>';
  const { data } = await api(action, params);
  data.forEach(row => {
    const o = document.createElement('option');
    o.value = valueFn(row); o.textContent = labelFn(row);
    sel.appendChild(o);
  });
}

/* ── THEME TOGGLE ─────────────────────────────────────────── */
function toggleTheme() {
  const html = document.documentElement;
  const current = html.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', next);
  document.getElementById('themeBtn').textContent = next === 'dark' ? '🌙' : '☀️';
  localStorage.setItem('farmacia-theme', next);
}

/* ── NAVIGATION ──────────────────────────────────────────── */
const pageTitles = {
  dashboard    : ['Dashboard',                   'Resumen general del sistema'],
  productos    : ['Productos',                   'Inventario general'],
  'ing-compra' : ['Ingreso – Compra Propia',     'Medicamentos adquiridos por la ONG'],
  'ing-csmc'   : ['Ingreso – CSMC',              'Centro de Salud Mental Comunitario'],
  'ing-hosp'   : ['Ingreso – Otros Hospitales',  'Consultas externas'],
  'ing-don'    : ['Ingreso – Donaciones',         'Medicamentos por donación'],
  salidas      : ['Salida en Bloque',            'Egreso masivo de medicamentos'],
  pacientes    : ['Lista de Pacientes',          'Gestión de pacientes'],
  kardex       : ['Kardex',                      'Historial por paciente'],
  ampollas     : ['Ampollas',                    'Ingresos y salidas'],
  jarabes      : ['Jarabes',                     'Ingresos y salidas'],
  gotas        : ['Gotas Oftalmológicas/Óticas', 'Ingresos y salidas'],
  lociones     : ['Lociones Varias',             'Ingresos y salidas'],
  soluciones   : ['Soluciones',                  'Dextrosa, Suero, Agua Estéril'],
  materiales   : ['Materiales de Salud',         'Insumos médicos'],
};
const catPages = {ampollas:'ampoules',jarabes:'syrups',gotas:'drops',lociones:'lotions',soluciones:'solutions',materiales:'materials'};

let _currentPage = 'dashboard';

function showPage(name, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const pg = document.getElementById('page-' + name);
  if (pg) pg.classList.add('active');
  if (el) el.classList.add('active');
  const t = pageTitles[name] || [name, ''];
  document.getElementById('topbarTitle').textContent = t[0];
  document.getElementById('topbarSub').textContent   = t[1];
  _currentPage = name;

  if (name === 'dashboard')  loadDashboard();
  if (name === 'productos')  loadProductos();
  if (name === 'ing-compra') loadIngresos('own_purchase',  'tbl-compra');
  if (name === 'ing-csmc')   loadIngresos('mental_health', 'tbl-csmc');
  if (name === 'ing-hosp')   loadIngresos('other_hospital','tbl-hosp');
  if (name === 'ing-don')    loadIngresos('donation',      'tbl-don');
  if (name === 'salidas')    loadSalidas();
  if (name === 'pacientes')  loadPacientes();
  if (name === 'kardex')     initKardex();
  if (catPages[name])        loadCatPage(name, catPages[name]);
}

/* ── DASHBOARD ───────────────────────────────────────────── */
async function loadDashboard() {
  try {
    const { stats, productos, movimientos } = await api('dashboard_stats');
    document.getElementById('d-totalProd').textContent = stats.total_productos;
    document.getElementById('d-totalPac').textContent  = stats.total_pacientes;
    document.getElementById('d-ingHoy').textContent    = stats.ingresos_hoy;
    document.getElementById('d-salHoy').textContent    = stats.salidas_hoy;
    document.getElementById('d-stockBajo').textContent = stats.stock_bajo;

    const ab = document.getElementById('alertBar');
    if (parseInt(stats.stock_bajo) > 0) {
      ab.style.display = 'flex';
      document.getElementById('alertMsg').textContent = `${stats.stock_bajo} producto(s) con stock bajo o por vencer.`;
    } else { ab.style.display = 'none'; }

    const tp = document.getElementById('dash-prod-table');
    tp.innerHTML = productos.length ? productos.map(p =>
      `<tr><td><strong>${h(p.nombre)}</strong></td>
       <td><span class="badge badge-gray">${catLabel(p.categoria)}</span></td>
       <td><span class="badge ${p.stock<=p.stock_min?'badge-red':'badge-green'}">${p.stock}</span></td>
       <td><span class="badge ${srcBadge(p.origen)}">${srcLabel(p.origen)}</span></td></tr>`
    ).join('') : '<tr><td colspan="4" class="empty-state">Sin datos</td></tr>';

    const tm = document.getElementById('dash-mov-table');
    tm.innerHTML = movimientos.length ? movimientos.map(m =>
      `<tr><td><span class="badge ${m.tipo==='entry'?'badge-green':'badge-red'}">${m.tipo==='entry'?'📥 Ingreso':'📤 Salida'}</span></td>
       <td>${h(m.prod_nombre||'—')}</td><td>${m.cantidad}</td><td>${fmtDate(m.fecha)}</td></tr>`
    ).join('') : '<tr><td colspan="4" class="empty-state">Sin datos</td></tr>';
  } catch(e) { showToast(e.message,'error'); }
}

/* ── PRODUCTOS ───────────────────────────────────────────── */
async function loadProductos() {
  const tb = document.getElementById('tblProductos');
  tb.innerHTML = '<tr><td colspan="8"><div class="loading"><div class="spinner"></div> Cargando...</div></td></tr>';
  try {
    const { data } = await api('list_productos');
    if (!data.length) { tb.innerHTML = '<tr><td colspan="8" class="empty-state">No hay productos registrados</td></tr>'; return; }
    tb.innerHTML = data.map(p => {
      const exp = p.vencimiento && new Date(p.vencimiento) < new Date();
      const low = p.stock <= p.stock_min;
      return `<tr>
        <td><code>${h(p.codigo||'—')}</code></td>
        <td><strong>${h(p.nombre)}</strong>${p.concentracion?`<br><small style="color:var(--text3)">${h(p.concentracion)}</small>`:''}</td>
        <td><span class="badge badge-gray">${catLabel(p.categoria)}</span></td>
        <td><span class="badge ${low?'badge-red':'badge-green'}">${p.stock}</span></td>
        <td>${p.vencimiento&&p.vencimiento!=='0000-00-00'?`<span class="badge ${exp?'badge-red':'badge-amber'}">${fmtDate(p.vencimiento)}</span>`:'—'}</td>
        <td><span class="badge ${srcBadge(p.origen)}">${srcLabel(p.origen)}</span></td>
        <td><span class="badge ${exp?'badge-red':low?'badge-amber':'badge-green'}">${exp?'Vencido':low?'Stock Bajo':'Activo'}</span></td>
        <td style="white-space:nowrap">
          <button class="btn btn-secondary btn-sm btn-icon" onclick="editProducto(${p.id})" title="Editar">✏️</button>
          <button class="btn btn-danger btn-sm btn-icon" onclick="confirmDelete('producto',${p.id})" title="Eliminar">🗑️</button>
        </td></tr>`;
    }).join('');
  } catch(e) { showToast(e.message,'error'); }
}
function openNuevoProducto() {
  document.getElementById('modalProductoTitle').textContent = 'Nuevo Producto';
  document.getElementById('prod-id').value = '';
  ['p-codigo','p-nombre','p-pres','p-conc','p-lote','p-ubic','p-prov','p-obs','p-vence'].forEach(id => { const el=document.getElementById(id); if(el) el.value=''; });
  document.getElementById('p-stock').value    = '0';
  document.getElementById('p-stockmin').value = '10';
  document.getElementById('p-cat').value    = 'medicines';
  document.getElementById('p-origen').value = 'own_purchase';
  openModal('modalProducto');
}
async function editProducto(id) {
  try {
    const { data } = await api('list_productos');
    const p = data.find(x => x.id == id); if (!p) return;
    document.getElementById('modalProductoTitle').textContent = 'Editar Producto';
    document.getElementById('prod-id').value     = p.id;
    document.getElementById('p-codigo').value    = p.codigo||'';
    document.getElementById('p-nombre').value    = p.nombre;
    document.getElementById('p-cat').value       = p.categoria;
    document.getElementById('p-origen').value    = p.origen;
    document.getElementById('p-pres').value      = p.presentacion||'';
    document.getElementById('p-conc').value      = p.concentracion||'';
    document.getElementById('p-stock').value     = p.stock;
    document.getElementById('p-stockmin').value  = p.stock_min;
    document.getElementById('p-vence').value     = p.vencimiento&&p.vencimiento!=='0000-00-00'?p.vencimiento:'';
    document.getElementById('p-lote').value      = p.lote||'';
    document.getElementById('p-ubic').value      = p.ubicacion||'';
    document.getElementById('p-prov').value      = p.proveedor||'';
    document.getElementById('p-obs').value       = p.observaciones||'';
    openModal('modalProducto');
  } catch(e) { showToast(e.message,'error'); }
}
async function saveProducto() {
  const nombre = document.getElementById('p-nombre').value.trim();
  if (!nombre) { showToast('El nombre es obligatorio','error'); return; }
  try {
    const res = await api('save_producto', {
      id:document.getElementById('prod-id').value, codigo:document.getElementById('p-codigo').value,
      nombre, categoria:document.getElementById('p-cat').value, origen:document.getElementById('p-origen').value,
      presentacion:document.getElementById('p-pres').value, concentracion:document.getElementById('p-conc').value,
      stock:document.getElementById('p-stock').value, stock_min:document.getElementById('p-stockmin').value,
      vencimiento:document.getElementById('p-vence').value, lote:document.getElementById('p-lote').value,
      ubicacion:document.getElementById('p-ubic').value, proveedor:document.getElementById('p-prov').value,
      observaciones:document.getElementById('p-obs').value,
    }, 'POST');
    showToast(res.msg,'success'); closeModal('modalProducto'); loadProductos(); loadDashboard();
  } catch(e) { showToast(e.message,'error'); }
}

/* ── INGRESOS ────────────────────────────────────────────── */
let _ingresoSource = 'own_purchase';
let _ingresoCategory = null;
async function openIngreso(source, category = null) {
  _ingresoSource = source; _ingresoCategory = category;
  const titles = {own_purchase:'Registrar Ingreso – Compra Propia',mental_health:'Registrar Ingreso – CSMC Salud Mental',other_hospital:'Registrar Ingreso – Otros Hospitales',donation:'Registrar Donación'};
  document.getElementById('modalIngresoTitle').textContent = titles[source] || 'Registrar Ingreso';
  document.getElementById('ing-fecha').value = new Date().toISOString().split('T')[0];
  document.getElementById('ing-qty').value   = '1';
  document.getElementById('ing-inst').value  = '';
  document.getElementById('ing-notas').value = '';
  await fillSelect('ing-prod','options_productos',category?{categoria:category}:{},r=>r.id,r=>`${r.nombre} (Stock: ${r.stock})`);
  openModal('modalIngreso');
}
async function saveIngreso() {
  const prodId = document.getElementById('ing-prod').value;
  const qty    = document.getElementById('ing-qty').value;
  if (!prodId || !qty || parseInt(qty) < 1) { showToast('Selecciona un producto y cantidad válida','error'); return; }
  try {
    const res = await api('save_ingreso', {
      producto_id:prodId, cantidad:qty, fuente:_ingresoSource,
      institucion:document.getElementById('ing-inst').value,
      notas:document.getElementById('ing-notas').value,
      fecha:document.getElementById('ing-fecha').value,
    }, 'POST');
    showToast(res.msg,'success'); closeModal('modalIngreso');
    const map = {own_purchase:'tbl-compra',mental_health:'tbl-csmc',other_hospital:'tbl-hosp',donation:'tbl-don'};
    if (map[_ingresoSource]) loadIngresos(_ingresoSource, map[_ingresoSource]);
    loadDashboard();
  } catch(e) { showToast(e.message,'error'); }
}
async function loadIngresos(fuente, tableId) {
  const tb = document.getElementById(tableId);
  if (!tb) return;
  tb.innerHTML = '<tr><td colspan="7"><div class="loading"><div class="spinner"></div> Cargando...</div></td></tr>';
  try {
    const { data } = await api('list_movimientos', {fuente, tipo:'entry'});
    if (!data.length) { tb.innerHTML = '<tr><td colspan="7" class="empty-state">No hay ingresos registrados</td></tr>'; return; }
    tb.innerHTML = data.map(m => `<tr>
      <td>${fmtDate(m.fecha)}</td>
      <td>${h(m.prod_nombre||'—')}</td>
      <td>${m.prod_cat?`<span class="badge badge-gray">${catLabel(m.prod_cat)}</span>`:'—'}</td>
      <td><span class="badge badge-green">+${m.cantidad}</span></td>
      <td>${h(m.institucion||'—')}</td>
      <td>${h(m.notas||'—')}</td>
      <td><button class="btn btn-danger btn-sm btn-icon" onclick="confirmDelete('movimiento',${m.id})">🗑️</button></td>
    </tr>`).join('');
  } catch(e) { showToast(e.message,'error'); }
}

/* ── SALIDAS ─────────────────────────────────────────────── */
async function openSalida() {
  document.getElementById('sal-fecha').value = new Date().toISOString().split('T')[0];
  document.getElementById('sal-qty').value   = '1';
  document.getElementById('sal-dest').value  = '';
  document.getElementById('sal-notas').value = '';
  await fillSelect('sal-prod','options_productos',{},r=>r.id,r=>`${r.nombre} (Stock: ${r.stock})`);
  openModal('modalSalida');
}
async function saveSalida() {
  const prodId = document.getElementById('sal-prod').value;
  const qty    = document.getElementById('sal-qty').value;
  if (!prodId || !qty || parseInt(qty) < 1) { showToast('Selecciona un producto y cantidad válida','error'); return; }
  try {
    const res = await api('save_salida', {
      producto_id:prodId, cantidad:qty,
      destino:document.getElementById('sal-dest').value,
      notas:document.getElementById('sal-notas').value,
      fecha:document.getElementById('sal-fecha').value,
    }, 'POST');
    showToast(res.msg,'success'); closeModal('modalSalida'); loadSalidas(); loadDashboard();
  } catch(e) { showToast(e.message,'error'); }
}
async function loadSalidas() {
  const tb = document.getElementById('tblSalidas');
  if (!tb) return;
  tb.innerHTML = '<tr><td colspan="6"><div class="loading"><div class="spinner"></div></div></td></tr>';
  try {
    const { data } = await api('list_movimientos', {tipo:'exit'});
    if (!data.length) { tb.innerHTML = '<tr><td colspan="6" class="empty-state">No hay salidas registradas</td></tr>'; return; }
    tb.innerHTML = data.map(m => `<tr>
      <td>${fmtDate(m.fecha)}</td>
      <td>${h(m.prod_nombre||'—')}</td>
      <td><span class="badge badge-red">-${m.cantidad}</span></td>
      <td>${h(m.destino||'—')}</td>
      <td>${h(m.notas||'—')}</td>
      <td><button class="btn btn-danger btn-sm btn-icon" onclick="confirmDelete('movimiento',${m.id})">🗑️</button></td>
    </tr>`).join('');
  } catch(e) { showToast(e.message,'error'); }
}

/* ── PACIENTES ───────────────────────────────────────────── */
async function loadPacientes() {
  const tb = document.getElementById('tblPacientes');
  tb.innerHTML = '<tr><td colspan="6"><div class="loading"><div class="spinner"></div></div></td></tr>';
  try {
    const { data } = await api('list_pacientes');
    if (!data.length) { tb.innerHTML = '<tr><td colspan="6" class="empty-state">No hay pacientes registrados</td></tr>'; return; }
    tb.innerHTML = data.map(p => `<tr>
      <td><code>${h(p.codigo)}</code></td>
      <td><strong>${h(p.nombre)} ${h(p.apellido)}</strong></td>
      <td>${h(p.dni||'—')}</td>
      <td>${h(p.telefono||'—')}</td>
      <td><span class="badge ${p.genero==='F'?'badge-purple':'badge-blue'}">${p.genero==='F'?'Femenino':p.genero==='M'?'Masculino':'Otro'}</span></td>
      <td style="white-space:nowrap">
        <button class="btn btn-secondary btn-sm btn-icon" onclick="editPaciente(${p.id})" title="Editar">✏️</button>
        <button class="btn btn-primary btn-sm" onclick="verKardex(${p.id})">📋 Kardex</button>
        <button class="btn btn-danger btn-sm btn-icon" onclick="confirmDelete('paciente',${p.id})" title="Eliminar">🗑️</button>
      </td>
    </tr>`).join('');
  } catch(e) { showToast(e.message,'error'); }
}
function openNuevoPaciente() {
  document.getElementById('pac-id').value = '';
  document.getElementById('modalPacienteTitle').textContent = 'Nuevo Paciente';
  ['pac-nombre','pac-apellido','pac-dni','pac-tel','pac-nac','pac-dir','pac-hist'].forEach(id => { const el=document.getElementById(id); if(el) el.value=''; });
  document.getElementById('pac-gen').value = 'M';
  openModal('modalPaciente');
}
async function editPaciente(id) {
  try {
    const { data } = await api('list_pacientes');
    const p = data.find(x => x.id == id); if (!p) return;
    document.getElementById('pac-id').value       = p.id;
    document.getElementById('modalPacienteTitle').textContent = 'Editar Paciente';
    document.getElementById('pac-nombre').value   = p.nombre;
    document.getElementById('pac-apellido').value = p.apellido;
    document.getElementById('pac-dni').value      = p.dni||'';
    document.getElementById('pac-tel').value      = p.telefono||'';
    document.getElementById('pac-nac').value      = p.nacimiento&&p.nacimiento!=='0000-00-00'?p.nacimiento:'';
    document.getElementById('pac-gen').value      = p.genero;
    document.getElementById('pac-dir').value      = p.direccion||'';
    document.getElementById('pac-hist').value     = p.historia||'';
    openModal('modalPaciente');
  } catch(e) { showToast(e.message,'error'); }
}
async function savePaciente() {
  const nombre = document.getElementById('pac-nombre').value.trim();
  const apellido = document.getElementById('pac-apellido').value.trim();
  if (!nombre || !apellido) { showToast('Nombre y apellido son obligatorios','error'); return; }
  try {
    const res = await api('save_paciente', {
      id:document.getElementById('pac-id').value, nombre, apellido,
      dni:document.getElementById('pac-dni').value, telefono:document.getElementById('pac-tel').value,
      nacimiento:document.getElementById('pac-nac').value, genero:document.getElementById('pac-gen').value,
      direccion:document.getElementById('pac-dir').value, historia:document.getElementById('pac-hist').value,
    }, 'POST');
    showToast(res.msg,'success'); closeModal('modalPaciente'); loadPacientes();
  } catch(e) { showToast(e.message,'error'); }
}

/* ── KARDEX ──────────────────────────────────────────────── */
let _kardexPatientId = null;
function initKardex() { if (_kardexPatientId) loadKardex(_kardexPatientId); }
async function verKardex(pacienteId) {
  _kardexPatientId = pacienteId;
  showPage('kardex', document.querySelector('[data-page="kardex"]'));
  await loadKardex(pacienteId);
}
async function loadKardex(pacienteId) {
  try {
    const { data, paciente } = await api('list_kardex', {paciente_id: pacienteId});
    if (paciente) {
      document.getElementById('kh-nombre').textContent   = `${paciente.nombre} ${paciente.apellido}`;
      document.getElementById('kh-codigo').textContent   = paciente.codigo;
      document.getElementById('kh-dni').textContent      = paciente.dni || '—';
      document.getElementById('kh-historia').textContent = paciente.historia || '—';
    }
    const tb = document.getElementById('tblKardex');
    if (!data.length) { tb.innerHTML = '<tr><td colspan="6" class="empty-state">Sin registros en kardex</td></tr>'; return; }
    tb.innerHTML = data.map(k => `<tr>
      <td>${fmtDate(k.fecha)}</td>
      <td>${h(k.prod_nombre||'—')}</td>
      <td>${k.prod_cat?`<span class="badge badge-gray">${catLabel(k.prod_cat)}</span>`:'—'}</td>
      <td><span class="badge ${k.tipo==='exit'?'badge-red':'badge-green'}">${k.tipo==='exit'?'📤 Entrega':'📥 Devolución'}</span></td>
      <td>${k.tipo==='exit'?'-':'+'} ${k.cantidad}</td>
      <td>${h(k.notas||'—')}</td>
    </tr>`).join('');
  } catch(e) { showToast(e.message,'error'); }
}
async function openKardexEntry() {
  document.getElementById('ke-fecha').value = new Date().toISOString().split('T')[0];
  document.getElementById('ke-qty').value   = '1';
  document.getElementById('ke-notas').value = '';
  document.getElementById('ke-tipo').value  = 'exit';
  await fillSelect('ke-pac',  'options_pacientes', {}, r=>r.id, r=>`${r.nombre} ${r.apellido} – ${r.dni||''}`);
  await fillSelect('ke-prod', 'options_productos', {}, r=>r.id, r=>`${r.nombre} (Stock: ${r.stock})`);
  if (_kardexPatientId) document.getElementById('ke-pac').value = _kardexPatientId;
  openModal('modalKardexEntry');
}
async function saveKardexEntry() {
  const pacId  = document.getElementById('ke-pac').value;
  const prodId = document.getElementById('ke-prod').value;
  const qty    = document.getElementById('ke-qty').value;
  if (!pacId || !prodId || parseInt(qty)<1) { showToast('Completa todos los campos','error'); return; }
  try {
    const res = await api('save_kardex', {
      paciente_id:pacId, producto_id:prodId,
      tipo:document.getElementById('ke-tipo').value,
      cantidad:qty, fecha:document.getElementById('ke-fecha').value,
      notas:document.getElementById('ke-notas').value,
    }, 'POST');
    showToast(res.msg,'success'); closeModal('modalKardexEntry');
    if (_kardexPatientId) loadKardex(_kardexPatientId);
  } catch(e) { showToast(e.message,'error'); }
}

/* ── CATEGORY PAGES ──────────────────────────────────────── */
async function loadCatPage(page, categoria) {
  const cont = document.getElementById('cat-content-' + page);
  if (!cont) return;
  cont.innerHTML = '<div class="loading"><div class="spinner"></div> Cargando...</div>';
  try {
    const [prodRes, movRes] = await Promise.all([api('list_productos'), api('list_movimientos')]);
    const prods = prodRes.data.filter(p => p.categoria === categoria);
    const movs  = movRes.data.filter(m => prods.find(p => p.id == m.producto_id));
    let html = `<div class="table-card" style="margin-bottom:14px">
      <div class="table-header"><h3>Productos – ${catLabel(categoria)}</h3></div>
      <table><thead><tr><th>Código</th><th>Nombre</th><th>Stock</th><th>Vencimiento</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>`;
    if (!prods.length) html += '<tr><td colspan="6" class="empty-state">Sin productos</td></tr>';
    prods.forEach(p => {
      const exp = p.vencimiento && p.vencimiento!=='0000-00-00' && new Date(p.vencimiento) < new Date();
      const low = p.stock <= p.stock_min;
      html += `<tr>
        <td><code>${h(p.codigo||'—')}</code></td><td><strong>${h(p.nombre)}</strong></td>
        <td><span class="badge ${low?'badge-red':'badge-green'}">${p.stock}</span></td>
        <td>${p.vencimiento&&p.vencimiento!=='0000-00-00'?`<span class="badge ${exp?'badge-red':'badge-amber'}">${fmtDate(p.vencimiento)}</span>`:'—'}</td>
        <td><span class="badge ${exp?'badge-red':low?'badge-amber':'badge-green'}">${exp?'Vencido':low?'Stock Bajo':'Activo'}</span></td>
        <td><button class="btn btn-danger btn-sm btn-icon" onclick="confirmDelete('producto',${p.id})">🗑️</button></td>
      </tr>`;
    });
    html += `</tbody></table></div><div class="table-card">
      <div class="table-header"><h3>Movimientos – ${catLabel(categoria)}</h3></div>
      <table><thead><tr><th>Fecha</th><th>Tipo</th><th>Producto</th><th>Cantidad</th><th>Origen/Destino</th></tr></thead><tbody>`;
    if (!movs.length) html += '<tr><td colspan="5" class="empty-state">Sin movimientos</td></tr>';
    movs.forEach(m => {
      const pr = prods.find(p => p.id == m.producto_id);
      html += `<tr>
        <td>${fmtDate(m.fecha)}</td>
        <td><span class="badge ${m.tipo==='entry'?'badge-green':'badge-red'}">${m.tipo==='entry'?'📥 Ingreso':'📤 Salida'}</span></td>
        <td>${h(pr?pr.nombre:'—')}</td>
        <td>${m.tipo==='entry'?'+':'−'}${m.cantidad}</td>
        <td>${h(m.institucion||m.destino||srcLabel(m.fuente)||'—')}</td>
      </tr>`;
    });
    html += '</tbody></table></div>';
    cont.innerHTML = html;
  } catch(e) { cont.innerHTML = `<div class="empty-state">${e.message}</div>`; }
}

/* ── DELETE CONFIRM ──────────────────────────────────────── */
let _deleteAction = null;
function confirmDelete(type, id) {
  _deleteAction = async () => {
    try {
      if (type==='producto')   await api('delete_producto',   {id}, 'POST');
      if (type==='paciente')   await api('delete_paciente',   {id}, 'POST');
      if (type==='movimiento') await api('delete_movimiento', {id}, 'POST');
      closeModal('modalConfirm');
      showToast('Registro eliminado','success');
      loadDashboard();
      if (type==='producto') loadProductos();
      if (type==='paciente') loadPacientes();
    } catch(e) { showToast(e.message,'error'); }
  };
  openModal('modalConfirm');
}
document.getElementById('confirmDeleteBtn').addEventListener('click', () => {
  if (_deleteAction) _deleteAction();
});

/* ── PDF EXPORT (genérico por página) ───────────────────── */
function getPDFTableData(page) {
  // Returns { title, head, body } based on page
  const configs = {
    productos: {
      title: 'Inventario de Productos',
      tableId: 'tblProductos',
      head: ['Código','Nombre','Categoría','Stock','Vencimiento','Origen','Estado'],
      cols: [0,1,2,3,4,5,6]
    },
    'ing-compra': { title:'Ingresos – Compra Propia', tableId:'tbl-compra', head:['Fecha','Producto','Categoría','Cantidad','Proveedor','Notas'], cols:[0,1,2,3,4,5] },
    'ing-csmc':   { title:'Ingresos – CSMC',          tableId:'tbl-csmc',   head:['Fecha','Producto','Categoría','Cantidad','Institución','Notas'], cols:[0,1,2,3,4,5] },
    'ing-hosp':   { title:'Ingresos – Otros Hospitales', tableId:'tbl-hosp', head:['Fecha','Producto','Categoría','Cantidad','Hospital','Notas'], cols:[0,1,2,3,4,5] },
    'ing-don':    { title:'Ingresos – Donaciones',    tableId:'tbl-don',    head:['Fecha','Producto','Categoría','Cantidad','Donante','Notas'], cols:[0,1,2,3,4,5] },
    salidas:      { title:'Salidas en Bloque',         tableId:'tblSalidas', head:['Fecha','Producto','Cantidad','Destino','Notas'], cols:[0,1,2,3,4] },
    pacientes:    { title:'Lista de Pacientes',        tableId:'tblPacientes',head:['Código','Nombre','DNI','Teléfono','Género'], cols:[0,1,2,3,4] },
    kardex:       { title:'Kardex de Paciente',        tableId:'tblKardex',  head:['Fecha','Medicamento','Categoría','Tipo','Cantidad','Notas'], cols:[0,1,2,3,4,5] },
  };

  // For category pages
  const catMap = { ampollas:'ampoules', jarabes:'syrups', gotas:'drops', lociones:'lotions', soluciones:'solutions', materiales:'materials' };
  if (catMap[page]) {
    return { title: `Categoría: ${catLabel(catMap[page])}`, dynamic: page };
  }

  return configs[page] || null;
}

async function exportPagePDF(page) {
  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const cfg = getPDFTableData(page);
    if (!cfg) { exportPDF(); return; }

    const pageTitle = pageTitles[page] ? pageTitles[page][0] : page;
    const today = new Date().toLocaleDateString('es-PE');

    // Header
    doc.setFillColor(13, 17, 23);
    doc.rect(0, 0, 210, 28, 'F');
    doc.setFontSize(14);
    doc.setTextColor(255, 255, 255);
    doc.setFont(undefined, 'bold');
    doc.text('FarmaciaONG', 14, 12);
    doc.setFontSize(10);
    doc.setFont(undefined, 'normal');
    doc.setTextColor(139, 148, 158);
    doc.text(pageTitle, 14, 20);
    doc.setTextColor(139, 148, 158);
    doc.text(`Generado: ${today}`, 150, 12);

    if (cfg.dynamic) {
      // Category page
      const [prodRes, movRes] = await Promise.all([api('list_productos'), api('list_movimientos')]);
      const prods = prodRes.data.filter(p => p.categoria === cfg.dynamic.replace('ampollas','ampoules').replace('jarabes','syrups').replace('gotas','drops').replace('lociones','lotions').replace('soluciones','solutions').replace('materiales','materials'));
      // use catMap
      const catKey = { ampollas:'ampoules', jarabes:'syrups', gotas:'drops', lociones:'lotions', soluciones:'solutions', materiales:'materials' }[cfg.dynamic] || cfg.dynamic;
      const prodsF = prodRes.data.filter(p => p.categoria === catKey);
      const movsF  = movRes.data.filter(m => prodsF.find(p => p.id == m.producto_id));
      doc.autoTable({
        head: [['Código','Nombre','Stock','Vencimiento','Estado']],
        body: prodsF.map(p => {
          const exp = p.vencimiento && p.vencimiento!=='0000-00-00' && new Date(p.vencimiento)<new Date();
          return [p.codigo||'—', p.nombre, p.stock, p.vencimiento&&p.vencimiento!=='0000-00-00'?fmtDate(p.vencimiento):'—', exp?'Vencido':p.stock<=p.stock_min?'Stock Bajo':'Activo'];
        }),
        startY: 34, styles:{fontSize:9,cellPadding:3},
        headStyles:{fillColor:[37,99,235]}, alternateRowStyles:{fillColor:[245,247,250]},
      });
      doc.addPage();
      doc.setFontSize(12); doc.setTextColor(40,40,40); doc.setFont(undefined,'bold');
      doc.text('Movimientos', 14, 14);
      doc.autoTable({
        head: [['Fecha','Tipo','Producto','Cantidad','Origen/Destino']],
        body: movsF.map(m => {
          const pr = prodsF.find(p => p.id == m.producto_id);
          return [fmtDate(m.fecha), m.tipo==='entry'?'Ingreso':'Salida', pr?pr.nombre:'—', (m.tipo==='entry'?'+':'-')+m.cantidad, m.institucion||m.destino||srcLabel(m.fuente)||'—'];
        }),
        startY: 20, styles:{fontSize:9,cellPadding:3},
        headStyles:{fillColor:[37,99,235]}, alternateRowStyles:{fillColor:[245,247,250]},
      });
    } else {
      // Read from DOM table
      const tb = document.getElementById(cfg.tableId);
      const rows = [];
      tb.querySelectorAll('tr').forEach(tr => {
        if (tr.style.display === 'none') return;
        const cells = tr.querySelectorAll('td');
        if (!cells.length) return;
        const row = [];
        cfg.cols.forEach(i => {
          if (cells[i]) row.push(cells[i].innerText.replace(/[\n\r]/g,' ').trim());
        });
        if (row.length) rows.push(row);
      });
      doc.autoTable({
        head: [cfg.head],
        body: rows,
        startY: 34, styles:{fontSize:9,cellPadding:3},
        headStyles:{fillColor:[37,99,235]}, alternateRowStyles:{fillColor:[245,247,250]},
      });
    }

    doc.save(`FarmaciaONG_${pageTitle.replace(/\s+/g,'_')}_${today.replace(/\//g,'-')}.pdf`);
    showToast('PDF exportado correctamente','success');
  } catch(e) { showToast('Error al exportar: ' + e.message,'error'); }
}

// Dashboard export (full inventory)
async function exportPDF() {
  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.setFillColor(13, 17, 23);
    doc.rect(0, 0, 210, 28, 'F');
    doc.setFontSize(14); doc.setTextColor(255,255,255); doc.setFont(undefined,'bold');
    doc.text('FarmaciaONG – Reporte de Inventario', 14, 12);
    doc.setFontSize(10); doc.setFont(undefined,'normal'); doc.setTextColor(139,148,158);
    doc.text(`Generado: ${new Date().toLocaleDateString('es-PE')}`, 14, 20);

    const { data } = await api('list_productos');
    doc.autoTable({
      head: [['Código','Nombre','Categoría','Stock','Vencimiento','Origen','Estado']],
      body: data.map(p => {
        const exp = p.vencimiento && p.vencimiento!=='0000-00-00' && new Date(p.vencimiento)<new Date();
        return [p.codigo||'—', p.nombre, catLabel(p.categoria), p.stock, p.vencimiento&&p.vencimiento!=='0000-00-00'?fmtDate(p.vencimiento):'—', srcLabel(p.origen), exp?'Vencido':p.stock<=p.stock_min?'Stock Bajo':'Activo'];
      }),
      startY: 34, styles:{fontSize:9,cellPadding:3},
      headStyles:{fillColor:[37,99,235]}, alternateRowStyles:{fillColor:[245,247,250]},
    });
    doc.save('FarmaciaONG_Inventario_' + new Date().toISOString().split('T')[0] + '.pdf');
    showToast('PDF exportado correctamente','success');
  } catch(e) { showToast(e.message,'error'); }
}

/* ── INIT ────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  // Restore saved theme
  const saved = localStorage.getItem('farmacia-theme');
  if (saved) {
    document.documentElement.setAttribute('data-theme', saved);
    document.getElementById('themeBtn').textContent = saved === 'dark' ? '🌙' : '☀️';
  }
  loadDashboard();
});

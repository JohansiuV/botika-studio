<?php
/**
 * ============================================================
 *  FarmaciaONG – Script de Reparación de Contraseña
 *  Ejecuta este archivo UNA SOLA VEZ desde el navegador:
 *  http://localhost/farmaciaong/reset_password.php
 *  Luego BORRA este archivo por seguridad.
 * ============================================================
 */
require_once __DIR__ . '/includes/config.php';

$usuario    = 'admin';
$contrasena = 'admin123';
$newHash    = password_hash($contrasena, PASSWORD_BCRYPT);

try {
    // Verificar si el usuario existe
    $stmt = db()->prepare("SELECT id FROM usuarios WHERE username = ?");
    $stmt->execute([$usuario]);
    $user = $stmt->fetch();

    if ($user) {
        // Actualizar contraseña
        $upd = db()->prepare("UPDATE usuarios SET password = ?, activo = 1 WHERE username = ?");
        $upd->execute([$newHash, $usuario]);
        $msg  = "✅ ¡Contraseña actualizada correctamente!";
        $tipo = "ok";
    } else {
        // Crear usuario si no existe
        $ins = db()->prepare("INSERT INTO usuarios (username, password, nombre, rol, activo) VALUES (?, ?, 'Administrador', 'admin', 1)");
        $ins->execute([$usuario, $newHash]);
        $msg  = "✅ Usuario admin creado correctamente.";
        $tipo = "ok";
    }
} catch (PDOException $e) {
    $msg  = "❌ Error de base de datos: " . $e->getMessage();
    $tipo = "err";
}
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"/>
<title>Reset Contraseña – FarmaciaONG</title>
<style>
  body{font-family:system-ui,sans-serif;background:#f5f5f5;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;}
  .box{background:#fff;border-radius:14px;padding:40px;box-shadow:0 8px 30px rgba(0,0,0,.12);max-width:480px;width:100%;text-align:center;}
  h1{font-size:22px;margin-bottom:8px;}
  .ok{color:#16a34a;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:14px 20px;margin:20px 0;font-size:15px;}
  .err{color:#dc2626;background:#fff0f0;border:1px solid #fecaca;border-radius:8px;padding:14px 20px;margin:20px 0;font-size:15px;}
  .creds{background:#f8f8f8;border:1px solid #e0e0e0;border-radius:8px;padding:14px;margin:16px 0;font-family:monospace;font-size:14px;text-align:left;}
  a{display:inline-block;margin-top:12px;background:#0a0a0a;color:#fff;text-decoration:none;padding:11px 24px;border-radius:8px;font-size:14px;}
  .warn{font-size:12px;color:#f59e0b;margin-top:18px;}
</style>
</head>
<body>
<div class="box">
  <h1>🔧 Reparación de Contraseña</h1>
  <div class="<?= $tipo ?>">
    <?= $msg ?>
  </div>
  <?php if ($tipo === 'ok'): ?>
  <div class="creds">
    <strong>Usuario:</strong> admin<br>
    <strong>Contraseña:</strong> admin123
  </div>
  <a href="index.php">→ Ir al Login</a>
  <p class="warn">⚠ Borra este archivo (reset_password.php) después de usarlo.</p>
  <?php endif; ?>
</div>
</body>
</html>

CREATE DATABASE IF NOT EXISTS farmaciaong CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE farmaciaong;

-- Usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  username    VARCHAR(60)  NOT NULL UNIQUE,
  password    VARCHAR(255) NOT NULL,
  nombre      VARCHAR(120) NOT NULL,
  rol         ENUM('admin','farmaceutico','visualizador') DEFAULT 'farmaceutico',
  activo      TINYINT(1) DEFAULT 1,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Contrasena: admin123 (hash bcrypt compatible PHP)
INSERT INTO usuarios (username, password, nombre, rol, activo) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrador', 'admin', 1)
ON DUPLICATE KEY UPDATE password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', activo = 1;

-- Productos
CREATE TABLE IF NOT EXISTS productos (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  codigo        VARCHAR(30)  NOT NULL UNIQUE,
  nombre        VARCHAR(200) NOT NULL,
  categoria     ENUM('medicines','ampoules','syrups','drops','solutions','materials','lotions') NOT NULL,
  origen        ENUM('own_purchase','mental_health','other_hospital','donation','return') DEFAULT 'own_purchase',
  presentacion  VARCHAR(100),
  concentracion VARCHAR(100),
  stock         INT          NOT NULL DEFAULT 0,
  stock_min     INT          NOT NULL DEFAULT 10,
  vencimiento   DATE,
  lote          VARCHAR(60),
  ubicacion     VARCHAR(60),
  proveedor     VARCHAR(150),
  observaciones TEXT,
  activo        TINYINT(1) DEFAULT 1,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Movimientos
CREATE TABLE IF NOT EXISTS movimientos (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  tipo          ENUM('entry','exit') NOT NULL,
  producto_id   INT NOT NULL,
  cantidad      INT NOT NULL,
  fuente        ENUM('own_purchase','mental_health','other_hospital','donation','return','') DEFAULT '',
  destino       VARCHAR(200),
  institucion   VARCHAR(200),
  notas         TEXT,
  fecha         DATE NOT NULL,
  usuario_id    INT,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE,
  FOREIGN KEY (usuario_id)  REFERENCES usuarios(id)  ON DELETE SET NULL
);

-- Pacientes
CREATE TABLE IF NOT EXISTS pacientes (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  codigo        VARCHAR(30)  NOT NULL UNIQUE,
  nombre        VARCHAR(100) NOT NULL,
  apellido      VARCHAR(100) NOT NULL,
  dni           VARCHAR(12),
  telefono      VARCHAR(20),
  nacimiento    DATE,
  genero        ENUM('M','F','other') DEFAULT 'M',
  direccion     VARCHAR(300),
  historia      TEXT,
  activo        TINYINT(1) DEFAULT 1,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Kardex
CREATE TABLE IF NOT EXISTS kardex (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  paciente_id   INT NOT NULL,
  producto_id   INT NOT NULL,
  tipo          ENUM('exit','entry') NOT NULL DEFAULT 'exit',
  cantidad      INT NOT NULL,
  fecha         DATE NOT NULL,
  notas         TEXT,
  usuario_id    INT,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE,
  FOREIGN KEY (usuario_id)  REFERENCES usuarios(id)  ON DELETE SET NULL
);

-- Datos de muestra
INSERT INTO productos (codigo, nombre, categoria, origen, presentacion, concentracion, stock, stock_min, vencimiento, lote, ubicacion, proveedor) VALUES
('MED-001','Paracetamol 500mg','medicines','own_purchase','Tableta','500mg',150,20,'2026-12-01','L2024-01','A-1','DIGEMID'),
('MED-002','Amoxicilina 500mg','medicines','donation','Capsula','500mg',80,15,'2026-08-15','L2024-02','A-2','Donante Cruz Roja'),
('AMP-001','Metoclopramida 10mg/2ml','ampoules','other_hospital','Ampolla','10mg/2ml',45,10,'2026-06-30','A2024-01','B-1','Hospital Regional'),
('JAR-001','Ibuprofeno Suspension 200mg/5ml','syrups','own_purchase','Frasco 120ml','200mg/5ml',30,10,'2026-04-20','S2024-01','C-1','InkaFarma'),
('SOL-001','Cloruro de Sodio 0.9% 1000ml','solutions','mental_health','Bolsa IV','0.9%',60,15,'2026-09-01','D2024-01','D-1','CSMC'),
('MAT-001','Gasas Esteriles 10x10cm','materials','donation','Paquete x10','-',200,50,NULL,'M2024-01','E-1','OPS'),
('GOT-001','Tobramicina 0.3% Colirio','drops','own_purchase','Frasco 5ml','0.3%',8,10,'2026-11-20','G2024-01','F-1','Farmindustria'),
('MAT-002','Guantes Esteriles Quirurgicos T7','materials','other_hospital','Par','-',120,30,NULL,'M2024-02','E-2','Hospital Loayza'),
('AMP-002','Dexametasona 4mg/2ml','ampoules','mental_health','Ampolla','4mg/2ml',25,8,'2026-03-10','A2024-02','B-2','CSMC'),
('LOC-001','Betametasona Crema 0.05%','lotions','donation','Tubo 30g','0.05%',15,5,'2026-07-01','L2024-03','G-1','Minsa Donacion');

INSERT INTO pacientes (codigo, nombre, apellido, dni, telefono, nacimiento, genero, direccion, historia) VALUES
('PAC-001','Maria','Garcia Lopez','43218765','987654321','1985-04-12','F','Jr. Las Flores 123, Lima','Hipertension arterial'),
('PAC-002','Carlos','Mendoza Rios','56789012','912345678','1972-09-30','M','Av. Lima 456, Callao','Diabetes tipo 2'),
('PAC-003','Ana','Torres Vega','31245678','999888777','1990-01-15','F','Calle Real 789','Asma bronquial');

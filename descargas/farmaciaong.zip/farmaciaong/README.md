# FarmaciaONG – Sistema de Gestión Farmacéutica
## Instalación en 4 pasos

### 1. Requisitos
- PHP 8.0+ con PDO y PDO_MySQL
- MySQL 5.7+ o MariaDB 10.3+
- Apache / Nginx (o `php -S localhost:8000`)

### 2. Base de Datos
```sql
mysql -u root -p < database.sql
```
Esto crea la base de datos `farmaciaong` con todas las tablas y datos de muestra.

### 3. Configuración
Editar `includes/config.php` con tus credenciales:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // tu usuario MySQL
define('DB_PASS', '');           // tu contraseña MySQL
define('DB_NAME', 'farmaciaong');
```

### 4. Ejecutar
```bash
# Opción rápida con PHP built-in server:
php -S localhost:8000

# Luego abrir: http://localhost:8000
```

---

## Credenciales por defecto
| Campo    | Valor     |
|----------|-----------|
| Usuario  | `admin`   |
| Contraseña | `admin123` |

> ⚠️ Cambiar la contraseña en producción ejecutando:
> ```sql
> UPDATE usuarios SET password = '$2y$10$...' WHERE username = 'admin';
> ```
> Generar hash: `php -r "echo password_hash('nueva_clave', PASSWORD_DEFAULT);"`

---

## Estructura de Archivos
```
farmaciaong/
├── index.php          ← Login
├── app.php            ← Aplicación principal
├── api.php            ← API AJAX (CRUD)
├── logout.php         ← Cerrar sesión
├── database.sql       ← Script de base de datos
├── includes/
│   ├── config.php     ← Configuración de BD
│   ├── auth.php       ← Autenticación y sesiones
│   └── helpers.php    ← Funciones auxiliares
└── assets/
    ├── css/app.css    ← Estilos (tema blanco)
    └── js/app.js      ← JavaScript del frontend
```

## Tablas de la Base de Datos
| Tabla        | Descripción                        |
|--------------|------------------------------------|
| `usuarios`   | Usuarios del sistema               |
| `productos`  | Inventario de medicamentos         |
| `movimientos`| Ingresos y salidas                 |
| `pacientes`  | Pacientes registrados              |
| `kardex`     | Historial de medicación/paciente   |
